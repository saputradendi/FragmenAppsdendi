package com.example.fragmenappsdendi;

import android.app.Activity;

public class SecondActivity extends Activity {
}
